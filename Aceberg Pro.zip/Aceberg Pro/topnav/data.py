

data = {
        "topnav": {
            "bg": "rgb(54,64,95)",
            "radius": "4px",
            "width": 200,
            "radius": "4px"
            },
        "currentpagelabel":{
            "label":"工作台",
            "color":"#ffffff"
        },
        "to_btn":{
            "width":32,
            "height":32,
            "focusbackground":"rgba(81,93,128,1)",
            "nobackground":"rgba(81,93,128,0)"
        }
}
