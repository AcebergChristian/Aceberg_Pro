data = {"columndata": ["id", "usrid", "姓名", "电话", "角色", "权限", "创建时间"],
        "tabeldata": [["0001", "Ace_000001", "Aceberg", "15942498121", "s_admin", "ALL", "2020-08-08 08:08:08"],
                      ["0002", "Ace_as4gvb", "Buricerf", "15942231231", "admin", {
                          "workbench": 1, "tablewid": 1, "widgetview": 1, "management": 0}, "2020-09-08 08:08:08"],
                      ["0003", "Ace_az1dfd", "Longago", "18523437655", "loc_admin", {
                          "workbench": 1, "tablewid": 1, "widgetview": 1, "management": 0}, "2020-09-18 08:08:08"],
                      ["0004", "Ace_ba79ja", "Alicerio", "18568345655", "common", {
                          "workbench": 1, "tablewid": 0, "widgetview": 0, "management": 0}, "2020-10-08 08:08:08"],
                      ["0005", "Ace_cad16d", "Micheal", "18134524657", "common", {
                          "workbench": 1, "tablewid": 0, "widgetview": 0, "management": 0}, "2020-12-08 08:08:08"],
                      ["0006", "Ace_cfg93f", "Jsonlover", "18098876653", "common", {
                          "workbench": 1, "tablewid": 0, "widgetview": 0, "management": 0}, "2020-12-18 08:08:08"]
                      ]
        }
