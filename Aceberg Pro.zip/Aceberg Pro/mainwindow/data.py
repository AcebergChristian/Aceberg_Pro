

data = {
        "mainwindow": {
            "TITLE":"Aceberg Pro",
            "bg": "rgb(28,35,56)"
        }
}
